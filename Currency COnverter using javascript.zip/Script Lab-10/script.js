function getExchange() { // Function to retrieve exchange rates
    let amount = document.querySelector("#convert").value; // Get the amount to convert
    let fcurrency = document.querySelector("#change-currency").value; // Get the currency to convert from
    let tcurrency = document.querySelector("#into-currency").value; // Get the currency to convert to

    const API_KEY = 'cbe8edb8ec17ceac12e2c9d6'; // API key for accessing exchange rate API

    let url = `https://v6.exchangerate-api.com/v6/${API_KEY}/pair/${fcurrency}/${tcurrency}/${amount}`; // Construct the API URL

    fetch(url) // Fetch data from the API
        .then(response => {
            if(response.ok) { // Check if response is okay
                return response.json(); // Parse response as JSON
            }
            throw new Error('Network Not OK'); // Throw error if response is not okay
        })
        .then(data => { // Handle data from the API
            console.log(data); // Log data to console (for debugging)
            let res = data.conversion_result; // Get the converted amount
            document.getElementById("output").innerHTML = `Converted amount: ${res} ${tcurrency.toUpperCase()}`; // Display converted amount
            document.getElementById("rate-of-exchange").textContent = data.conversion_rate; // Display exchange rate
        })
        .catch(error => { // Catch any errors that occur during the process
            console.error(error); // Log errors to console
        });
}

document.getElementById("form-converter").addEventListener("submit", function(event) { // Event listener for form submission
    event.preventDefault(); // Prevent default form submission
    getExchange(); // Call the function to get exchange rates
});

function resetExchangeRate() { // Function to reset exchange rate
    document.getElementById("rate-of-exchange").textContent = ""; // Reset exchange rate display
}

document.querySelector("button[type='reset']").addEventListener("click", function(event) { // Event listener for reset button
    document.getElementById("output").innerHTML = "Converted amount: "; // Reset converted amount display
    resetExchangeRate(); // Call the function to reset exchange rate
});
